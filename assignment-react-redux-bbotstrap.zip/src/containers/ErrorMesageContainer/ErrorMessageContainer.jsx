import React, { Component } from "react";

class ErrorMessageContainer extends Component {
  render() {
    return <div>An Error Occured</div>;
  }
}

export default ErrorMessageContainer;
